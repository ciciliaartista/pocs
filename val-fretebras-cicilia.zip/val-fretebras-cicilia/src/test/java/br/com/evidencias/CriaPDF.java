package br.com.evidencias;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.imageio.ImageIO;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.itextpdf.text.Document;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.pdf.PdfWriter;

import org.openqa.selenium.firefox.*;
import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Point;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;

import org.openqa.selenium.TakesScreenshot;
import org.apache.commons.io.FileUtils;

import br.com.uolmais.buscas.TestBuscas;
import br.com.uolmais.generic.metodosGenericos;
import br.com.uolmais.video.*;





public class CriaPDF extends metodosGenericos{
	
	public static Document CriaPDFs(File dir2) throws Throwable {
		
		Document doc = new Document(PageSize.A4);
		FileOutputStream os = new FileOutputStream(dir2 + ".pdf");
		PdfWriter.getInstance(doc, os);
		doc.open();
		
		return doc;
		
	}
	
	public static void capturaImagemEvidencia() throws IOException {
		
	
		// Chame método
		CriaPDF.captureScreenShot(driver, null, null);
		
		// Maximize a janela
		driver.manage().window().maximize();
		
	}

	public static void captureScreenShot(WebDriver driver, Document doc, Image image) throws IOException {
		
		// Take screenshot and store as a file format
		File src =((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		
		try {
			
			FileUtils.copyFile(src, new File("C:/fretebras/resultados/evidencias/images/screenshot.png"));
			
			//Search for drop down
//			WebElement element = driver.findElement(By.id("month"));
			
			WebElement element = driver.findElement(By.cssSelector(".main-ad-list .li:nth-child(1)"));
	 
	        // Take screen shot of whole web page
	        File screenShot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
	 
	        // Calculate the width and height of the drop down element
	        Point p = element.getLocation();
	        int width = element.getSize().getWidth();
	        int height = element.getSize().getHeight();
	 
	        // Create Rectangle of same width as of drop down Web Element
	        Rectangle rect = new Rectangle(width, height);
	 
	        BufferedImage img = null;
	        img = ImageIO.read(screenShot);
	 
	        //Crop Image of drop down web element from the screen shot
	        BufferedImage dest = img.getSubimage(p.getX(), p.getY(), rect.width, rect.height);
	 
	        // write cropped image into File Object
	        ImageIO.write(dest, "png", screenShot);
	 
	        //Copy Image into particular directory
	        FileUtils.copyFile(screenShot,
	        new File("C:/fretebras/resultados/evidencias/images/WebElementScreenShot.png"));
			
			
								
		}
		catch (Throwable e){//;
		
			System.out.println(e.getMessage());
		}
	
	}

	public static void gravaImagensPdf(Document doc, Image image) throws IOException {		
								
			try {
				
				image = Image.getInstance("C:/fretebras/resultados/evidencias/images/screenshot.png");
				doc.add(image);											
				image.scaleAbsolute(567, 1020);
				image.scaleToFit(567, 1020);
				 
				
			}
			catch (Throwable e){
			
				System.out.println(e.getMessage());
		
			
			}
		
		
	}


	@Override
	public WebDriver createDriver() {
		// TODO Auto-generated method stub
		return null;
	}
		
}
