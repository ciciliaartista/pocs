package br.com.uolmais.buscas;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import br.com.evidencias.CriaPDF;
import br.com.uolmais.mobile.android.BrowserStack_Android_5;

public class BuscaVideos extends TestBuscas {
	
	public void BuscaVideosMetodo() throws IOException {
	
			//Entra no site da olx
			driver.get("https://www.olx.com.br/");
		
			//Seleciona o título do primeiro produto listado
			String valorBusca = "Canon";

			System.out.println("Busca "+valorBusca);
			
			//Preenche o campo de busca
			WebElement infomaValorBusca = driver.findElement(By.name("q"));
			infomaValorBusca.sendKeys(" "+valorBusca);
			
			wait(5000);
			System.out.println("Preencheu a busca");
			
			// clica no botão Buscar
			WebElement buttonBuscar = driver.findElement(By.cssSelector("button[type='submit']"));
			buttonBuscar.click();
			
	}


	@Override
	public WebDriver createDriver() {
		// TODO Auto-generated method stub
		return null;
	}

}
