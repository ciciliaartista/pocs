package br.com.uolmais.buscas;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import br.com.evidencias.CriaPDF;
import br.com.uolmais.mobile.android.BrowserStack_Android_5;

public class PercorrePaginacao extends TestBuscas {
	
	public void Paginacao() throws IOException {
	
		
			System.out.println("Entrou na paginação");
		
			//Chrome
			WebElement pagin = driver.findElement(By.cssSelector(".module_pagination .list li:nth-child(2) a"));
			pagin.click();	
			
			CriaPDF.captureScreenShot(driver, doc, image);
			CriaPDF.gravaImagensPdf(doc, image);
			
			
	}
			

	@Override
	public WebDriver createDriver() {
		// TODO Auto-generated method stub
		return null;
	}

}
