package br.com.uolmais.buscas;

import java.io.File;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestChrome extends TestBuscas {

	
	@Override
	public WebDriver createDriver() {
		
		System.setProperty("webdriver.chrome.driver", "C:/fretebras/drivers/chromedriver.exe");	
		return new ChromeDriver();
		
	
	}
	
	

}
