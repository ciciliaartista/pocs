package br.com.uolmais.mobile.android;

import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import br.com.uolmais.buscas.TestBuscas;
import br.com.uolmais.generic.TestGeneric;

import java.net.URL;
import java.util.List;

public class BrowserStack_Android_8 extends TestGeneric{

  public static final String USERNAME = "uolmais1"; 
  public static final String AUTOMATE_KEY = "81LodMsUgMp3YcqURgyJ";
  public static final String URL = "https://" + USERNAME + ":" + AUTOMATE_KEY + "@hub-cloud.browserstack.com/wd/hub";
  static int i = 1;

  public static void main(String[] args) throws Exception {
	  
	System.out.println("Setou o usuario "+USERNAME);  

    DesiredCapabilities caps = new DesiredCapabilities();
    
    caps.setCapability ("browserstack.local", "true");
    
    System.out.println("Denifiu as capacidades "+caps); 

    caps.setCapability("browserName", "android");
    caps.setCapability("device", "Google Pixel 2");
    caps.setCapability("realMobile", "true");
    caps.setCapability("os_version", "8.0");
    
    System.out.println("Denifiu o dispositivo "+caps.getBrowserName()); 
     
    WebDriver driver = new RemoteWebDriver(new URL(URL), caps);
  
  		List<WebElement> elements = driver.findElements(By.cssSelector(".uolplayer"));
  		
          for (WebElement el : elements) {

          	System.out.println("MediaId "+el.getAttribute("mediaid") + " ID: " + el.getAttribute("id"));

          }

    
    driver.get
    ("https://noticias.uol.com.br/cotidiano/ultimas-noticias/2018/03/21/dos-14-aos-93-anos-mulheres-querem-manter-vivo-legado-de-marielle.htm?autoplayMobile=true&logger=true");
    
    wait(50000);
    
    System.out.println(driver.getTitle());
    driver.quit();

  }

@Override
public WebDriver createDriver() {
	// TODO Auto-generated method stub
	return null;
}

}