package br.com.uolmais.buscas;


import java.io.File;
import java.io.IOException;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;

import com.itextpdf.text.Document;
import com.itextpdf.text.Image;
import br.com.evidencias.CriaPDF;
import br.com.uolmais.generic.metodosGenericos;

/**
 * Unit test for simple App.
 */
public abstract class TestBuscas extends metodosGenericos {

	public static File dir2;
	public static Document doc = null;
	public static Image image = null;
	String nomeBrownse;
	static int i = 1;

	@Before
	public void setUp() throws IOException {
		
		driver = createDriver();
		
		// Maximize a janela
		driver.manage().window().maximize();

	}
	
	@After
	public void tearDown() throws Throwable {
		
		System.out.println("Gerando evidências");
		
		dir2 = new File("C:/fretebras/evidencia");
		dir2.mkdir();
		
		Document doc = CriaPDF.CriaPDFs(dir2);
		CriaPDF.gravaImagensPdf(doc, null);
		
		
		doc.close();
		System.exit(0);
		

	}
	
	@Test
	public void testBusca() throws IOException {
		
			
		// Acessa a Página da OLX e faz a busca
		BuscaVideos busca = new BuscaVideos();
		busca.BuscaVideosMetodo();
		
		// Percorre paginasção
		PercorrePaginacao navega = new PercorrePaginacao();
		navega.Paginacao();
				
		wait(15000);

	
	try {
//		CriaPDF.captureScreenShot(driver, doc, image);
		CriaPDF.gravaImagensPdf(doc, image);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	try {
		CriaPDF.gravaImagensPdf(doc, image);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}


}
	

}