package br.com.uolmais.buscas;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.itextpdf.text.Document;

import br.com.evidencias.CriaPDF;

public class TestFirefox extends TestBuscas {

	public WebDriver createDriver() {
			
		return new FirefoxDriver();
		
		
	}
	


}
