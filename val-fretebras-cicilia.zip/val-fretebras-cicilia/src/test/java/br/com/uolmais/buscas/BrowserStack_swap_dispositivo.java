package br.com.uolmais.buscas;

import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import br.com.uolmais.buscas.TestBuscas;
import br.com.uolmais.generic.metodosGenericos;
import java.net.URL;
import java.util.List;

public class BrowserStack_swap_dispositivo extends metodosGenericos{

  public static final String USERNAME = "ciciliamoreira1"; 
  public static final String AUTOMATE_KEY = "hEr4wufHzWE7XEfvEAPG";
  public static final String URL = "https://" + USERNAME + ":" + AUTOMATE_KEY + "@hub-cloud.browserstack.com/wd/hub";
  static int i = 1;

  public static void main(String[] args) throws Exception {
	  
	System.out.println("Setou o usuario "+USERNAME);  

    DesiredCapabilities caps = new DesiredCapabilities();
    
    caps.setCapability ("browserstack.local", "true");
    
    System.out.println("Denifiu as capacidades "+caps); 

    caps.setCapability("browserName", "iPhone");
    caps.setCapability("device", "iPhone 7");
    caps.setCapability("realMobile", "true");
    caps.setCapability("os_version", "10.3");
  
    
    System.out.println("Denifiu o dispositivo "+caps.getBrowserName()); 
     
    driver = new RemoteWebDriver(new URL(URL), caps);
  
    wait(5000);
    
    BuscaVideos busca = new BuscaVideos();
    busca.BuscaVideosMetodo();
    wait(15000);
    
    driver.close();


  }

@Override
public WebDriver createDriver() {
	// TODO Auto-generated method stub
	return null;
}

}