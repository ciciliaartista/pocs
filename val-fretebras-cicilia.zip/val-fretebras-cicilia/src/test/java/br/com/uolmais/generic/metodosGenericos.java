package br.com.uolmais.generic;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;

public abstract class metodosGenericos {
	
	public static WebDriver driver;
	public abstract WebDriver createDriver();
	private static final int TIMEOUT = 30;
	private static final List<Class<? extends WebDriverException>> IGNORE_EXCEPTION_LIST_DEFAULT = Arrays.asList(NoAlertPresentException.class, NoSuchElementException.class, UnhandledAlertException.class);



	
	protected static void wait(int time) {
		try {
			Thread.sleep(time);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	private static WebElement waitForClickOf(WebDriver driver, By locator) {
		return getDefaultFluentWait(driver).until(ExpectedConditions.elementToBeClickable(locator));
	}

	public static Wait<WebDriver> getDefaultFluentWait(WebDriver driver) {
		return new FluentWait<WebDriver>(driver)
				        .withTimeout(TIMEOUT, TimeUnit.SECONDS)
						.ignoreAll(IGNORE_EXCEPTION_LIST_DEFAULT);
	}
	
	public static WebElement waitForPresenceOf(WebDriver driver, By locator) {
		return getDefaultFluentWait(driver).until(ExpectedConditions.presenceOfElementLocated(locator));
	}
	


}
